# Frontend
React app for Smart Energy Dashboard
import React, { useState, useEffect } from "react";

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [data, setData] = useState(null);

  const handleLogin = () => {
    if (username && password) {
      setIsLoggedIn(true);
      fetch(`${process.env.REACT_APP_API_URL || "http://localhost:5000"}/api/data`)
        .then((res) => res.json())
        .then((json) => setData(json));
    }
  };

  if (!isLoggedIn) {
    return (
      <div style={{ padding: "2rem", maxWidth: "400px", margin: "auto" }}>
        <h2>Login / Signup</h2>
        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          style={{ display: "block", margin: "10px 0", width: "100%" }}
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          style={{ display: "block", margin: "10px 0", width: "100%" }}
        />
        <button onClick={handleLogin}>Login</button>
      </div>
    );
  }

  return (
    <div style={{ padding: "2rem" }}>
      <h2>IoT Smart Energy Meter Dashboard</h2>
      {data ? (
        <div style={{ marginBottom: "1rem" }}>
          <p>Total Power Consumption: {data.power}</p>
          <p>Total Bill: {data.bill}</p>
          <p>Live Data Date: {data.date}</p>
        </div>
      ) : (
        <p>Loading data...</p>
      )}
      <div>
        <button>View Live Data</button>
        <button style={{ marginLeft: "1rem" }}>Date-wise Data</button>
        <button style={{ marginLeft: "1rem" }}>Month-wise Data</button>
        <button style={{ marginLeft: "1rem" }}>Download Excel</button>
      </div>
    </div>
  );
}

export default App;
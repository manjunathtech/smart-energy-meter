# Backend
Node.js + Express API for Smart Energy Dashboard